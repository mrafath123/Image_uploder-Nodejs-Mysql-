require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const multer = require('multer');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const expressLayouts = require('express-ejs-layouts');

const app = express();

// Database connection
const db = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'image_uploader'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

// Message middleware
app.use((req, res, next) => {
  res.locals.message = req.session.message;
  delete req.session.message;
  next();
});

// EJS setup with layouts
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('layout', 'layouts/main');

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const filetypes = /jpe?g|png|gif/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    if (mimetype && extname) return cb(null, true);
    cb(new Error('Only image files are allowed!'));
  }
});

// Authentication middleware
const requireAuth = (req, res, next) => {
  if (!req.session.userId) {
    req.session.message = { type: 'error', text: 'Please login first' };
    return res.redirect('/login');
  }
  next();
};

// Routes
app.get('/', requireAuth, (req, res) => {
  db.query(
    'SELECT * FROM images WHERE user_id = ? ORDER BY uploaded_at DESC',
    [req.session.userId],
    (err, images) => {
      if (err) {
        console.error(err);
        req.session.message = { type: 'error', text: 'Failed to load images' };
        return res.redirect('/');
      }
      res.render('index', {
        title: 'Your Gallery',
        user: req.session.username,
        images: images || []
      });
    }
  );
});

// Auth Routes
app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect('/');
  res.render('login', { title: 'Login' });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
    if (err) {
      console.error(err);
      req.session.message = { type: 'error', text: 'Database error' };
      return res.redirect('/login');
    }
    
    if (results.length > 0 && bcrypt.compareSync(password, results[0].password)) {
      req.session.userId = results[0].id;
      req.session.username = results[0].username;
      req.session.message = { type: 'success', text: 'Login successful' };
      return res.redirect('/');
    }
    
    req.session.message = { type: 'error', text: 'Invalid username or password' };
    res.redirect('/login');
  });
});

app.get('/register', (req, res) => {
  res.render('register', { title: 'Register' });
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);
  
  db.query(
    'INSERT INTO users (username, password) VALUES (?, ?)',
    [username, hashedPassword],
    (err, results) => {
      if (err) {
        console.error(err);
        if (err.code === 'ER_DUP_ENTRY') {
          req.session.message = { type: 'error', text: 'Username already exists' };
        } else {
          req.session.message = { type: 'error', text: 'Registration failed' };
        }
        return res.redirect('/register');
      }
      req.session.message = { type: 'success', text: 'Registration successful! Please login' };
      res.redirect('/login');
    }
  );
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Image Routes
app.post('/upload', requireAuth, upload.single('image'), (req, res) => {
  if (!req.file) {
    req.session.message = { type: 'error', text: 'No file uploaded or invalid file type' };
    return res.redirect('/');
  }
  
  const imageData = {
    user_id: req.session.userId,
    filename: req.file.filename,
    filepath: '/uploads/' + req.file.filename,
    description: req.body.description || null
  };
  
  db.query('INSERT INTO images SET ?', imageData, (err, results) => {
    if (err) {
      console.error(err);
      req.session.message = { type: 'error', text: 'Failed to upload image' };
    } else {
      req.session.message = { type: 'success', text: 'Image uploaded successfully' };
    }
    res.redirect('/');
  });
});

app.post('/delete/:id', requireAuth, (req, res) => {
  db.query(
    'DELETE FROM images WHERE id = ? AND user_id = ?',
    [req.params.id, req.session.userId],
    (err, results) => {
      if (err) {
        console.error(err);
        req.session.message = { type: 'error', text: 'Failed to delete image' };
      } else {
        req.session.message = { type: 'success', text: 'Image deleted successfully' };
      }
      res.redirect('/');
    }
  );
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', {
    title: 'Error',
    message: err.message || 'Something went wrong!'
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});